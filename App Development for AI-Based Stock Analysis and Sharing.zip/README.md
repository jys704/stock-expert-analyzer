# Stock Expert Analyzer

**Stock Expert Analyzer**는 사용자가 매수 후보 종목을 입력하면 기술적 추세, 거래량, 거래대금, RSI, 이동평균, 테마 키워드, 리스크 메모를 종합해 전문가형 참고 리포트로 정리해 주는 독립형 웹앱입니다. 이 버전은 공통 비밀번호 방식 대신 **Firebase Authentication 이메일/비밀번호 로그인**을 사용하므로, 각 사용자는 본인의 Firebase 프로젝트에 등록된 개별 계정으로 접근할 수 있습니다.

> 이 도구는 투자 판단을 대신하지 않습니다. 출력되는 등급과 문장은 사용자가 입력한 지표를 바탕으로 한 참고용 분석이며, 실제 매수·매도 결정은 반드시 본인의 판단과 추가 검증을 거쳐야 합니다.

## 주요 기능

| 구분 | 구현 내용 |
|---|---|
| 사용자 로그인 | Firebase Authentication의 Email/Password 방식으로 개별 사용자 계정을 관리합니다. |
| 종목 입력 | 티커, 종목명, 현재가, 등락률, MA20, MA60, MA120, RSI14, 거래량, 20일 평균 거래량, 직전 20일·60일 고점, 거래대금을 입력합니다. |
| 전문가형 점수화 | 추세, 돌파, 거래량, 거래대금, RSI, 리스크 조건을 점수화해 S/A/B/C 등급을 표시합니다. |
| 리포트 생성 | 핵심 상승 논리, 과열 여부, 손절·관찰 기준, 다음 확인 사항을 리서치 노트 형태로 자동 작성합니다. |
| PDF 저장 | 분석 완료 후 리포트 영역을 PDF 파일로 저장할 수 있습니다. |
| 샘플 데이터 | NVDA, AAPL, MSFT 예시 데이터를 즉시 불러와 사용법을 확인할 수 있습니다. |
| 독립 배포 | 로컬 실행, GitHub 저장, Firebase Hosting 배포를 모두 지원하도록 `firebase.json`과 설정 템플릿을 포함했습니다. |

## 빠른 실행

프로젝트를 내려받은 뒤 패키지를 설치합니다.

```bash
pnpm install
```

그 다음 `firebase.env.template`의 내용을 참고해 프로젝트 루트에 `.env` 파일을 만들고, 본인의 Firebase 웹앱 설정값을 입력합니다. Firebase 설정이 없으면 로그인 화면에서 설정 누락 안내가 표시됩니다.

```bash
cp firebase.env.template .env
pnpm run dev
```

브라우저에서 표시되는 주소를 열고 Firebase Console에 등록한 이메일과 비밀번호로 로그인하면 분석 데스크로 들어갈 수 있습니다.

## Firebase Authentication 설정 방법

Firebase는 Google 계정별 프로젝트에 연결되므로, 각 사용자가 자기 Firebase 콘솔에서 새 프로젝트를 만들고 Authentication을 활성화하는 방식을 권장합니다. Firebase Authentication은 이메일/비밀번호 로그인 제공자를 지원하며, Firebase Hosting은 정적 파일 배포와 단일 페이지 앱 rewrite 설정을 지원합니다.[^1] [^2]

| 단계 | 위치 | 작업 |
|---|---|---|
| 1 | [Firebase Console](https://console.firebase.google.com/) | 새 프로젝트를 만들거나 기존 프로젝트를 선택합니다. |
| 2 | Project settings > General | Web app을 추가하고 Firebase SDK 설정값을 확인합니다. |
| 3 | 프로젝트 루트 | `firebase.env.template`을 참고해 `.env` 파일에 `VITE_FIREBASE_*` 값을 입력합니다. |
| 4 | Authentication > Sign-in method | **Email/Password** 제공자를 활성화합니다. |
| 5 | Authentication > Users | 접근을 허용할 사용자 이메일과 임시 비밀번호를 직접 등록합니다. |
| 6 | Authentication > Settings | 배포 도메인이 Authorized domains에 포함되어 있는지 확인합니다. |

`.env` 예시는 다음과 같습니다. 이 파일은 GitHub에 올리지 않는 것을 권장합니다.

```bash
VITE_FIREBASE_API_KEY=your_firebase_api_key
VITE_FIREBASE_AUTH_DOMAIN=your-project-id.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789012
VITE_FIREBASE_APP_ID=1:123456789012:web:abcdef1234567890
```

## PDF 저장 사용 방법

분석을 실행하면 리포트 카드 상단에 **PDF 저장** 버튼이 나타납니다. 이 버튼은 현재 리포트 화면을 캡처해 PDF로 저장하므로, 한글 텍스트가 깨지는 문제를 줄이고 사용자가 보는 화면과 비슷한 형태로 보관할 수 있습니다.

| 항목 | 설명 |
|---|---|
| 저장 파일명 | `종목코드-stock-report.pdf` 형식으로 저장됩니다. |
| 저장 대상 | 분석 등급, 점수, 핵심 논리, 리스크, 체크리스트가 포함된 리포트 영역입니다. |
| 주의 사항 | 브라우저에서 파일 다운로드 권한을 차단하면 저장이 되지 않을 수 있습니다. |

## GitHub에 저장하는 방법

이 프로젝트는 특정 회사 계정에 종속되지 않도록 원격 저장소 주소를 넣지 않은 상태로 유지하는 것이 좋습니다. 각 사용자는 자기 GitHub 계정에서 새 저장소를 만든 뒤 아래 순서로 연결하면 됩니다.

```bash
git init
git add .
git commit -m "Initial stock expert analyzer"
git branch -M main
git remote add origin https://github.com/본인계정/저장소명.git
git push -u origin main
```

이미 Git 저장소가 초기화되어 있다면 `git remote -v`로 원격 주소를 확인하고, 필요하면 아래처럼 자기 저장소로 바꾸면 됩니다.

```bash
git remote set-url origin https://github.com/본인계정/저장소명.git
```

## Firebase Hosting 배포 방법

Firebase CLI는 프로젝트 초기화와 Hosting 배포를 지원합니다.[^3] 이 앱에는 `firebase.json`이 포함되어 있으며, 빌드 결과물 위치는 `dist/public`으로 설정되어 있습니다.

| 단계 | 명령 또는 작업 | 설명 |
|---|---|---|
| 1 | `npm install -g firebase-tools` | Firebase CLI를 설치합니다. |
| 2 | `firebase login` | 본인의 Google/Firebase 계정으로 로그인합니다. |
| 3 | Firebase 콘솔에서 프로젝트 생성 | 예: `stock-analyzer-myname`처럼 개인 프로젝트를 만듭니다. |
| 4 | `.firebaserc.example` 복사 | `.firebaserc` 파일을 만들고 `YOUR_FIREBASE_PROJECT_ID`를 본인 프로젝트 ID로 바꿉니다. |
| 5 | `pnpm run build` | 정적 배포 파일을 `dist/public`에 생성합니다. |
| 6 | `firebase deploy --only hosting` | Firebase Hosting으로 배포합니다. |

`.firebaserc` 예시는 다음과 같습니다.

```json
{
  "projects": {
    "default": "본인_FIREBASE_PROJECT_ID"
  }
}
```

## 다른 사람에게 나누어 줄 때 권장 방식

이 앱은 중앙 서비스가 아니라 독립형 패키지로 쓰는 것이 목적입니다. 따라서 다른 사람에게 공유할 때는 완성된 GitHub 저장소 주소나 ZIP 파일을 전달하고, 각자가 자기 Firebase 프로젝트에서 사용자를 등록하도록 안내하는 것이 안전합니다.

| 공유 방식 | 권장 상황 | 주의점 |
|---|---|---|
| ZIP 파일 전달 | 개발 지식이 적은 사람에게 원본을 그대로 전달할 때 | 받은 사람이 직접 `.env`와 Firebase 프로젝트를 설정해야 합니다. |
| GitHub 저장소 공유 | 추후 수정과 버전 관리가 필요할 때 | 공개 저장소라면 `.env` 같은 민감 설정 파일을 올리지 않아야 합니다. |
| Firebase 배포 링크 공유 | 제한된 사용자에게 웹 링크를 제공할 때 | Firebase Console에서 허용할 사용자 이메일을 직접 만들고 관리해야 합니다. |

## 향후 개선 아이디어

현재 버전은 사용자가 입력한 지표를 바탕으로 브라우저 안에서 즉시 분석합니다. 이후에는 Firestore 저장 기능, 사용자별 관심종목 목록, 리포트 히스토리, 실시간 시세 API, AI 리포트 자동 생성 기능을 붙여 확장할 수 있습니다. 다만 API 키나 유료 데이터 서비스가 필요한 기능은 프론트엔드 정적 앱에 직접 넣기보다 백엔드나 보안 프록시를 통해 연결하는 편이 안전합니다.

## 검증 방법

아래 명령으로 TypeScript 검사와 프로덕션 빌드를 확인합니다.

```bash
pnpm run check
pnpm run build
```

Firebase 환경변수가 없는 개발 환경에서는 실제 로그인 성공까지 검증할 수 없지만, 설정 누락 안내와 빌드 안정성은 확인할 수 있습니다. 실제 Firebase 프로젝트 값을 넣은 뒤에는 등록된 이메일 계정으로 로그인, 샘플 데이터 로딩, 분석 실행, PDF 저장을 차례로 확인하세요.

## 참고 문서

[^1]: [Firebase Authentication with password-based accounts](https://firebase.google.com/docs/auth/web/password-auth)
[^2]: [Firebase Hosting configuration](https://firebase.google.com/docs/hosting/full-config)
[^3]: [Firebase CLI reference](https://firebase.google.com/docs/cli)
