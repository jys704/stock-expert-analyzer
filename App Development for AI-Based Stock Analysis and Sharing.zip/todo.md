# 작업 목록

- [x] 첨부된 질문·답변·PDF·기존 output.zip 구조를 검토해 앱 요구사항으로 정리한다.
- [x] 현재 작업 공간에서는 독립 실행 가능한 앱 소스와 설정 템플릿만 완성하고, 각 사용자가 자기 GitHub/Firebase 또는 로컬 환경에서 복사해 사용할 수 있도록 설계한다.
- [x] Firebase 프로젝트 ID, 호스팅 타깃, 저장소 원격 주소를 하드코딩하지 않고 문서와 설정 템플릿으로 분리한다.
- [x] 몇몇 사람만 접근할 수 있도록 비밀번호 기반 로그인 화면을 구현한다.
- [x] 주식 투자 전문가가 보는 것처럼 종목 분석 입력, 점수화, 리포트, 차트 해석 기능을 구현한다.
- [x] 기존 Python 코드와 output.zip 결과물을 참고해 브라우저에서 동작하는 분석 로직으로 재구성한다.
- [x] 각 사용자가 로컬 실행, GitHub 저장, Firebase 배포 중 원하는 방식으로 사용할 수 있도록 README와 배포 가이드를 작성한다.
- [ ] 최종 코드와 사용 가이드를 전달한다.

## 추가 요청 작업

- [x] 공통 비밀번호 로그인 방식을 제거하고 Firebase Authentication 이메일·비밀번호 로그인으로 전환한다.
- [x] Firebase 프로젝트 설정값을 사용자별 환경변수 템플릿으로 분리한다.
- [x] 로그인 상태 표시와 로그아웃 기능을 추가한다.
- [x] 분석 완료 리포트를 PDF 파일로 저장하는 버튼을 추가한다.
- [x] README와 인수인계 문서를 Firebase Authentication 및 PDF 저장 방식에 맞게 갱신한다.
- [x] 변경 후 타입 검사와 프로덕션 빌드를 통과시킨다.

## 개인 계정 이전 지원

- [ ] 최신 프로젝트 소스가 개인 계정 이전에 적합한지 확인한다.
- [ ] 이전용 압축 파일 또는 체크포인트 전달 방식을 정리한다.
- [ ] 개인 GitHub 저장소 생성 및 소스 업로드 절차를 안내한다.
- [ ] 개인 Firebase 프로젝트 생성, Authentication, Hosting 설정 절차를 안내한다.
- [ ] 개인 Manus 계정에서 이어서 수정할 때 필요한 체크리스트를 전달한다.

## 브라우저 인계 방식 이전

- [ ] GitHub 로그인 페이지를 열고 사용자가 직접 로그인하도록 인계한다.
- [ ] 개인 GitHub 저장소를 생성하거나 기존 저장소 연결 방식을 확정한다.
- [ ] Firebase Console을 열고 사용자가 직접 Google 계정으로 로그인하도록 인계한다.
- [ ] Firebase 프로젝트, Authentication, Hosting 설정값을 확인해 로컬 설정 파일에 반영한다.
- [ ] 배포 전 비밀번호 노출 이력에 따른 계정 보안 조치를 다시 안내한다.

## 사용자 직접 진행 방식

- [ ] 사용자가 자신의 PC에서 프로젝트 파일을 확보하는 방법을 안내한다.
- [ ] 사용자가 개인 GitHub 저장소에 직접 업로드하는 절차를 안내한다.
- [ ] 사용자가 Firebase Console에서 Authentication과 Hosting을 직접 설정하는 절차를 안내한다.
- [ ] 설정값 입력, 빌드, 배포, 오류 확인 방법을 안내한다.

## Codespaces package.json 문제 해결

- [ ] 현재 Codespaces 작업 폴더에 `package.json`이 없는 원인을 확인하도록 안내한다.
- [ ] 실제 프로젝트 폴더를 찾는 명령을 안내한다.
- [ ] 필요한 경우 React/Vite 프로젝트용 `package.json` 템플릿을 제공한다.
- [ ] `pnpm install`, `pnpm run dev`, `pnpm run build` 재시도 순서를 안내한다.


## Codespaces GitHub 업로드 오류 해결

- [ ] `github push`가 아니라 `git push`를 사용해야 함을 안내한다.
- [ ] `git status`와 `git remote -v`로 현재 저장소 상태를 확인하도록 안내한다.
- [ ] 원격 저장소가 없을 경우 `git remote add origin` 명령을 안내한다.
- [ ] 커밋 후 `git push -u origin main`으로 업로드하도록 안내한다.


## Codespaces Vite 빌드 오류 해결

- [ ] `Cannot resolve entry module index.html` 오류가 루트 `index.html` 누락 때문임을 안내한다.
- [ ] Codespaces에 실제 앱 소스 파일이 존재하는지 `ls`와 `find` 명령으로 확인하도록 안내한다.
- [ ] 소스 파일이 없으면 이전용 ZIP 또는 Manus 코드 다운로드 파일을 다시 업로드하도록 안내한다.
- [ ] 소스 파일 복구 후 `git add .`, `git commit`, `git push`, `pnpm run build` 순서로 재시도하도록 안내한다.


## Codespaces 전체 소스 복구

- [ ] `find` 결과가 비어 있어 실제 React 앱 소스가 Codespaces에 없음을 안내한다.
- [ ] Manus 체크포인트 또는 이전 ZIP에서 전체 소스를 다시 다운로드하도록 안내한다.
- [ ] Codespaces 탐색기에서 ZIP 업로드 또는 파일 전체 업로드 방법을 안내한다.
- [ ] 압축 해제 후 `index.html`, `client/src/App.tsx`, `client/src/pages/Home.tsx` 존재 여부를 확인하도록 안내한다.
- [ ] 복구 후 `pnpm install`, `pnpm run build`, `git add .`, `git commit`, `git push` 순서로 재진행하도록 안내한다.


## 풀스택 전환 및 파일 저장 기능 통합

- [x] 현재 정적 프론트엔드 프로젝트를 풀스택 프로젝트로 업그레이드한다.
- [x] 파일 저장 기능에 필요한 인증, 데이터베이스, 서버 라우트, 스토리지 흐름을 확인한다.
- [x] 파일 업로드, 파일 목록 조회, 다운로드 또는 열기 기능의 UI 위치를 설계한다.
- [x] 업로드된 파일의 메타데이터를 사용자 단위로 관리하는 구조를 구현한다.
- [x] 빌드와 기본 동작을 확인한 뒤 새 체크포인트를 저장한다.


## 전체 파일 다운로드 누락 문제

- [x] 코드 패널과 다운로드 ZIP에서 누락된 서버·스토리지 파일 범위를 확인한다.
- [x] 현재 프로젝트 루트의 실제 파일 목록과 사용자가 받은 파일 구조를 대조한다.
- [x] 누락 없이 받을 수 있는 전체 소스 압축본을 별도로 생성한다.
- [x] 압축본 안에 포함된 핵심 파일 목록과 적용 방법을 안내한다.

## 업로드 다운로드 ZIP 직접 비교

- [x] 사용자가 업로드한 ZIP 파일의 전체 파일 목록을 추출한다.
- [x] 현재 완성 소스 압축본의 전체 파일 목록과 비교한다.
- [x] 누락된 핵심 풀스택 파일과 일반 파일을 분류해 리포트로 작성한다.
- [x] 필요한 경우 누락 파일만 담은 보완 패키지와 전체 소스 패키지를 함께 전달한다.

## 전체 소스 덮어쓰기 이후 로컬 실행 안내

- [x] 사용자가 전체 소스를 덮어씌운 뒤 실행해야 할 명령 순서를 안내한다.
- [x] Firebase, 데이터베이스, Manus 내장 환경변수 등 필요한 환경변수 범위를 설명한다.
- [x] 로컬 실행과 Manus 내 미리보기 실행의 차이를 명확히 안내한다.
- [x] 실행 중 자주 발생하는 오류와 확인 방법을 안내한다.

## Codespaces 최신 소스 적용 문제

- [x] 사용자의 Codespaces 폴더에 최신 풀스택 소스가 적용되지 않아 `server/`, `drizzle/`, `db:push`가 없는 상태를 해결하도록 안내한다.
- [x] ZIP 압축 해제 위치와 중첩 폴더 여부를 확인하는 명령을 안내한다.
- [x] 최신 소스 적용 후 `package.json`, `server/`, `drizzle/` 확인 및 실행 순서를 안내한다.
- [x] Codespaces에서 ZIP을 푼 뒤 중첩 폴더 여부를 확인하는 구체적 명령을 사용자에게 안내한다.

## Codespaces package.json 누락 재복구

- [x] 현재 Codespaces 루트에 `README.md`와 `.git`만 있고 앱 소스가 없음을 설명한다.
- [x] ZIP 파일 위치를 찾는 명령과 업로드 필요 여부를 안내한다.
- [x] ZIP 압축 해제 후 중첩 폴더를 보정하고 `package.json`, `server`, `drizzle`, `client`를 검증하는 절차를 안내한다.
- [x] 잘못된 Git 원격 주소를 정리하고 올바른 저장소 URL 형식을 안내한다.

## Codespaces 복구 재개

- [x] ZIP 파일이 Codespaces 안에 존재하는지 확인하는 명령을 안내한다.
- [x] `find /workspaces -maxdepth 3 -name '*.zip'` 결과가 비어 있을 때, 완성본 ZIP을 Codespaces에 다시 업로드해야 함을 사용자에게 명시적으로 안내한다.
- [x] ZIP 파일을 `/workspaces/stock-expert-analyzer` 루트에 압축 해제하는 명령을 안내한다.
- [x] 중첩 폴더로 풀렸을 때 안쪽 파일을 루트로 이동하는 명령을 안내한다.
- [x] `package.json`, `server`, `drizzle`, `client` 존재 확인 후 `pnpm install`, `pnpm dev` 순서를 안내한다.
- [x] GitHub 원격 주소를 실제 사용자명 기반 URL로 재설정하는 명령을 안내한다.
