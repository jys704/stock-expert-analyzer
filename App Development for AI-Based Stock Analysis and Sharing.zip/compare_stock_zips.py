from __future__ import annotations

import json
import zipfile
from pathlib import Path

user_zip = Path('/home/ubuntu/upload/AppDevelopmentforAI-BasedStockAnalysisandSharing.zip')
complete_zip = Path('/home/ubuntu/stock-expert-analyzer-complete-source-7f344322-v2.zip')
out_dir = Path('/home/ubuntu/zip_compare_stock')
out_dir.mkdir(exist_ok=True)

PROJECT_PREFIX = 'stock-expert-analyzer/'

CORE_FILES = [
    'server/analysisUtils.ts',
    'server/analysisUtils.test.ts',
    'server/firebaseAuth.ts',
    'server/storage.ts',
    'server/db.ts',
    'server/routers.ts',
    'server/_core/storageProxy.ts',
    'server/_core/index.ts',
    'server/_core/context.ts',
    'drizzle/schema.ts',
    'drizzle/relations.ts',
    'drizzle/0001_lovely_ben_urich.sql',
    'drizzle/meta/0001_snapshot.json',
    'client/src/lib/trpc.ts',
    'client/src/_core/hooks/useAuth.ts',
    'client/src/pages/Home.tsx',
    'client/src/lib/firebase.ts',
    'package.json',
    'drizzle.config.ts',
    'vitest.config.ts',
]

EXCLUDE_PREFIXES = (
    'node_modules/',
    'dist/',
    '.git/',
    '.manus-logs/',
)

def norm_name(name: str) -> str | None:
    name = name.replace('\\', '/')
    if name.endswith('/'):
        return None
    while name.startswith('./'):
        name = name[2:]
    # complete source zip contains stock-expert-analyzer/ prefix and manifest at root.
    if name.startswith(PROJECT_PREFIX):
        name = name[len(PROJECT_PREFIX):]
    # user zip may wrap files in an arbitrary top-level folder; strip it if known folders are nested.
    parts = name.split('/')
    known_top = {'.firebaserc.example', '.gitignore', 'README.md', 'package.json', 'client', 'server', 'drizzle', 'shared', 'vite.config.ts'}
    if parts and parts[0] not in known_top and len(parts) > 1 and parts[1] in known_top:
        name = '/'.join(parts[1:])
    if not name or any(name.startswith(prefix) for prefix in EXCLUDE_PREFIXES):
        return None
    return name

def list_zip(path: Path) -> set[str]:
    with zipfile.ZipFile(path) as zf:
        return {n for raw in zf.namelist() if (n := norm_name(raw))}

user_files = list_zip(user_zip)
complete_files = list_zip(complete_zip)
missing_from_user = sorted(complete_files - user_files)
extra_in_user = sorted(user_files - complete_files)
common = sorted(user_files & complete_files)

core_rows = []
for f in CORE_FILES:
    core_rows.append({
        'file': f,
        'in_uploaded_zip': f in user_files,
        'in_complete_zip': f in complete_files,
        'status': 'OK' if f in user_files and f in complete_files else ('MISSING_IN_UPLOADED_ZIP' if f in complete_files and f not in user_files else 'OTHER'),
    })

summary = {
    'uploaded_zip': str(user_zip),
    'complete_zip': str(complete_zip),
    'uploaded_file_count': len(user_files),
    'complete_file_count': len(complete_files),
    'common_file_count': len(common),
    'missing_from_uploaded_count': len(missing_from_user),
    'extra_in_uploaded_count': len(extra_in_user),
    'core_missing_from_uploaded': [r['file'] for r in core_rows if r['status'] == 'MISSING_IN_UPLOADED_ZIP'],
}

(out_dir / 'uploaded_files.txt').write_text('\n'.join(sorted(user_files)) + '\n', encoding='utf-8')
(out_dir / 'complete_files.txt').write_text('\n'.join(sorted(complete_files)) + '\n', encoding='utf-8')
(out_dir / 'missing_from_uploaded.txt').write_text('\n'.join(missing_from_user) + '\n', encoding='utf-8')
(out_dir / 'extra_in_uploaded.txt').write_text('\n'.join(extra_in_user) + '\n', encoding='utf-8')
(out_dir / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# Markdown report
core_table = ['| 파일 | 업로드 ZIP | 완성본 ZIP | 판정 |', '|---|---:|---:|---|']
for r in core_rows:
    core_table.append(f"| `{r['file']}` | {'있음' if r['in_uploaded_zip'] else '없음'} | {'있음' if r['in_complete_zip'] else '없음'} | {r['status']} |")

missing_preview = missing_from_user[:80]
missing_table = ['| 구분 | 값 |', '|---|---:|']
missing_table.extend([
    f"| 업로드 ZIP 파일 수 | {len(user_files)} |",
    f"| 완성본 ZIP 파일 수 | {len(complete_files)} |",
    f"| 공통 파일 수 | {len(common)} |",
    f"| 업로드 ZIP에 없는 완성본 파일 수 | {len(missing_from_user)} |",
    f"| 업로드 ZIP에만 있는 파일 수 | {len(extra_in_user)} |",
])

report = f"""# 다운로드 ZIP 비교 리포트

업로드하신 다운로드 ZIP과 제가 별도로 만든 완성본 ZIP의 파일 목록을 정규화하여 비교했습니다. 비교 과정에서는 `node_modules`, `dist`, `.git`, `.manus-logs`처럼 배포·의존성·로그 성격의 폴더는 제외했습니다.

## 요약

{chr(10).join(missing_table)}

## 핵심 풀스택 파일 포함 여부

{chr(10).join(core_table)}

## 업로드 ZIP에 없는 완성본 파일 목록 미리보기

아래 목록은 전체 누락 목록 중 앞부분입니다. 전체 목록은 `missing_from_uploaded.txt`에 저장되어 있습니다.

```text
{chr(10).join(missing_preview) if missing_preview else '누락 파일 없음'}
```

## 결론

업로드하신 ZIP에는 완성본 기준으로 일부 파일이 누락되어 있습니다. 특히 핵심 풀스택 파일 중 `MISSING_IN_UPLOADED_ZIP`로 표시된 항목이 있으면, 해당 ZIP만으로는 제가 설명한 서버 저장·DB·인증 검증 흐름이 재현되지 않을 수 있습니다. 첨부할 완성본 ZIP을 기준으로 다시 내려받아 사용하시거나, 필요하면 누락 파일만 별도 복사해 기존 폴더에 덮어쓰면 됩니다.
"""
(out_dir / 'download_zip_comparison_report.md').write_text(report, encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
