from __future__ import annotations

from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

project = Path('/home/ubuntu/stock-expert-analyzer')
compare_dir = Path('/home/ubuntu/zip_compare_stock')
missing_list = compare_dir / 'missing_from_uploaded.txt'
out_zip = Path('/home/ubuntu/stock-expert-analyzer-missing-files-from-upload.zip')
report = compare_dir / 'download_zip_comparison_report.md'
summary = compare_dir / 'summary.json'

missing_files = [line.strip() for line in missing_list.read_text(encoding='utf-8').splitlines() if line.strip()]

with ZipFile(out_zip, 'w', ZIP_DEFLATED) as zf:
    zf.write(report, 'download_zip_comparison_report.md')
    zf.write(summary, 'summary.json')
    zf.write(missing_list, 'missing_from_uploaded.txt')
    for rel in missing_files:
        src = project / rel
        if src.is_file():
            zf.write(src, f'stock-expert-analyzer/{rel}')

print(out_zip)
print(f'missing_files={len(missing_files)}')
